
package com.example.internmentorchat

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun AuthScreen(
    onLoginSuccess: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("Intern") }
    var isSignup by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "InternConnect",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = if (isSignup) "Create Your Account" else "Welcome Back",
            fontSize = 20.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        if (isSignup) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Full Name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))
        }

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        if (isSignup) {
            Spacer(modifier = Modifier.height(16.dp))

            Text("Choose your role")

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = role == "Intern",
                        onClick = { role = "Intern" }
                    )
                    Text("Intern")
                }

                Spacer(modifier = Modifier.width(16.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = role == "Mentor",
                        onClick = { role = "Mentor" }
                    )
                    Text("Mentor")
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                message = ""

                if (email.isBlank() || password.isBlank() ||
                    (isSignup && name.isBlank())
                ) {
                    message = "Please fill all required fields"
                    return@Button
                }

                if (!android.util.Patterns.EMAIL_ADDRESS
                        .matcher(email.trim()).matches()
                ) {
                    message = "Enter a valid email address"
                    return@Button
                }

                if (password.length < 6) {
                    message = "Password must be at least 6 characters"
                    return@Button
                }

                loading = true

                if (isSignup) {

                    auth.createUserWithEmailAndPassword(
                        email.trim(),
                        password
                    ).addOnCompleteListener { task ->

                        if (task.isSuccessful) {

                            val uid = auth.currentUser?.uid

                            if (uid == null) {
                                loading = false
                                message = "Account created, but user ID was not found"
                                return@addOnCompleteListener
                            }

                            val userData = hashMapOf<String, Any>(
                                "name" to name.trim(),
                                "email" to email.trim(),
                                "role" to role,
                                "createdAt" to FieldValue.serverTimestamp()
                            )

                            val publicData = hashMapOf<String, Any>(
                                "uid" to uid,
                                "name" to name.trim(),
                                "role" to role,
                                "createdAt" to FieldValue.serverTimestamp()
                            )

                            val batch = db.batch()

                            batch.set(
                                db.collection("users").document(uid),
                                userData
                            )

                            batch.set(
                                db.collection("publicProfiles").document(uid),
                                publicData
                            )

                            batch.commit()
                                .addOnSuccessListener {
                                    loading = false
                                    onLoginSuccess()
                                }
                                .addOnFailureListener { error ->
                                    loading = false
                                    message =
                                        "Account created, but profile saving failed: " +
                                                (error.message ?: "Unknown error")
                                }

                        } else {
                            loading = false
                            message = task.exception?.message
                                ?: "Signup failed"
                        }
                    }

                } else {

                    auth.signInWithEmailAndPassword(
                        email.trim(),
                        password
                    ).addOnCompleteListener { task ->

                        loading = false

                        if (task.isSuccessful) {
                            onLoginSuccess()
                        } else {
                            message = task.exception?.message
                                ?: "Login failed"
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !loading
        ) {
            if (loading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp
                )
            } else {
                Text(if (isSignup) "Sign Up" else "Login")
            }
        }

        TextButton(
            onClick = {
                isSignup = !isSignup
                message = ""
            },
            enabled = !loading
        ) {
            Text(
                if (isSignup)
                    "Already have an account? Login"
                else
                    "Don't have an account? Sign Up"
            )
        }

        if (message.isNotBlank()) {
            Text(
                text = message,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
    }
}
