
package com.example.internmentorchat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

data class AppUser(
    val uid: String = "",
    val name: String = "",
    val role: String = ""
)

data class AppChat(
    val id: String = "",
    val chatName: String = "",
    val members: List<String> = emptyList(),
    val memberNames: Map<String, String> = emptyMap(),
    val type: String = "private",
    val lastMessage: String = ""
)

data class AppMessage(
    val id: String = "",
    val senderId: String = "",
    val text: String = "",
    val readBy: List<String> = emptyList()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                var uid by remember {
                    mutableStateOf(FirebaseAuth.getInstance().currentUser?.uid)
                }

                DisposableEffect(Unit) {
                    val authListener = FirebaseAuth.AuthStateListener { auth ->
                        uid = auth.currentUser?.uid
                    }
                    FirebaseAuth.getInstance().addAuthStateListener(authListener)
                    onDispose {
                        FirebaseAuth.getInstance().removeAuthStateListener(authListener)
                    }
                }

                if (uid == null) {
                    AuthScreen {
                        uid = FirebaseAuth.getInstance().currentUser?.uid
                    }
                } else {
                    ChatHomeScreen(
                        uid = uid!!,
                        onLogout = {
                            FirebaseAuth.getInstance().signOut()
                            uid = null
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ChatHomeScreen(
    uid: String,
    onLogout: () -> Unit
) {
    val db = remember { FirebaseFirestore.getInstance() }

    var users by remember { mutableStateOf(emptyList<AppUser>()) }
    var chats by remember { mutableStateOf(emptyList<AppChat>()) }
    var selectedChat by remember { mutableStateOf<AppChat?>(null) }
    var selectedUsers by remember { mutableStateOf(setOf<AppUser>()) }
    var showGroupDialog by remember { mutableStateOf(false) }
    var groupName by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    DisposableEffect(uid) {
        val profileListener = db.collection("publicProfiles")
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) {
                    error = exception.message ?: "Users load nahi huay"
                    return@addSnapshotListener
                }

                users = snapshot?.documents?.mapNotNull { doc ->
                    if (doc.id == uid) return@mapNotNull null

                    AppUser(
                        uid = doc.id,
                        name = doc.getString("name") ?: "User",
                        role = doc.getString("role") ?: "Intern"
                    )
                } ?: emptyList()
            }

        val chatListener = db.collection("chats")
            .whereArrayContains("members", uid)
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) {
                    error = exception.message ?: "Chats load nahi huay"
                    return@addSnapshotListener
                }

                chats = snapshot?.documents?.map { doc ->
                    AppChat(
                        id = doc.id,
                        chatName = doc.getString("chatName") ?: "Chat",
                        members = doc.get("members") as? List<String> ?: emptyList(),
                        memberNames = doc.get("memberNames") as? Map<String, String> ?: emptyMap(),
                        type = doc.getString("type") ?: "private",
                        lastMessage = doc.getString("lastMessage") ?: ""
                    )
                } ?: emptyList()
            }

        onDispose {
            profileListener.remove()
            chatListener.remove()
        }
    }

    fun createPrivateChat(user: AppUser) {
        val existing = chats.firstOrNull {
            it.type == "private" &&
                    it.members.toSet() == setOf(uid, user.uid)
        }

        if (existing != null) {
            selectedChat = existing
            return
        }

        val currentName = FirebaseAuth.getInstance()
            .currentUser?.displayName ?: "User"

        val members = listOf(uid, user.uid)

        val data = hashMapOf(
            "chatName" to user.name,
            "members" to members,
            "memberNames" to mapOf(
                uid to currentName,
                user.uid to user.name
            ),
            "type" to "private",
            "lastMessage" to "",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        db.collection("chats").add(data)
            .addOnSuccessListener { document ->
                selectedChat = AppChat(
                    id = document.id,
                    chatName = user.name,
                    members = members,
                    memberNames = data["memberNames"] as Map<String, String>,
                    type = "private"
                )
            }
            .addOnFailureListener {
                error = it.message ?: "Chat create nahi hui"
            }
    }

    fun createGroup() {
        val members = (selectedUsers.map { it.uid } + uid).distinct()
        if (members.size < 2 || groupName.isBlank()) return

        val names = selectedUsers.associate { it.uid to it.name }.toMutableMap()
        names[uid] = FirebaseAuth.getInstance().currentUser?.displayName ?: "User"

        val data = hashMapOf(
            "chatName" to groupName.trim(),
            "members" to members,
            "memberNames" to names,
            "type" to "group",
            "lastMessage" to "",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        db.collection("chats").add(data)
            .addOnSuccessListener { doc ->
                selectedChat = AppChat(
                    id = doc.id,
                    chatName = groupName.trim(),
                    members = members,
                    memberNames = names,
                    type = "group"
                )
                showGroupDialog = false
                selectedUsers = emptySet()
                groupName = ""
            }
            .addOnFailureListener {
                error = it.message ?: "Group create nahi hua"
            }
    }

    if (selectedChat != null) {
        ChatDetailScreen(
            chat = selectedChat!!,
            uid = uid,
            onBack = { selectedChat = null }
        )
        return
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("InternConnect", style = MaterialTheme.typography.headlineMedium)
        Text("Interns & Mentors Messaging")

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = { showGroupDialog = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Create Group Chat")
        }

        Text("Registered Users", style = MaterialTheme.typography.titleLarge)
        LazyColumn(Modifier.weight(1f)) {
            items(users) { user ->
                Card(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        .clickable { createPrivateChat(user) }
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(user.name, style = MaterialTheme.typography.titleMedium)
                        Text(user.role)
                        Text("Tap to start chat")
                    }
                }
            }
        }

        HorizontalDivider()
        Text("Your Chats", style = MaterialTheme.typography.titleLarge)

        LazyColumn(Modifier.weight(1f)) {
            items(chats) { chat ->
                Card(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        .clickable { selectedChat = chat }
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(chat.chatName, style = MaterialTheme.typography.titleMedium)
                        Text(chat.lastMessage.ifBlank { "Start conversation" })
                        Text(if (chat.type == "group") "Group" else "Private chat")
                    }
                }
            }
        }

        if (error.isNotBlank()) {
            Text(error, color = MaterialTheme.colorScheme.error)
        }

        TextButton(onClick = onLogout) {
            Text("Logout")
        }
    }

    if (showGroupDialog) {
        AlertDialog(
            onDismissRequest = { showGroupDialog = false },
            title = { Text("Create Group") },
            text = {
                Column {
                    OutlinedTextField(
                        value = groupName,
                        onValueChange = { groupName = it },
                        label = { Text("Group name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(Modifier.height(12.dp))

                    Text("Select group members (Select at least 1):")

                    if (users.isEmpty()) {
                        Text(
                            "No other registered users found. Create another user account to test group chat!",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    LazyColumn(Modifier.heightIn(max = 240.dp)) {
                        items(users) { user ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    selectedUsers = if (user in selectedUsers)
                                        selectedUsers - user
                                    else selectedUsers + user
                                }.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = user in selectedUsers,
                                    onCheckedChange = {
                                        selectedUsers = if (it)
                                            selectedUsers + user
                                        else selectedUsers - user
                                    }
                                )
                                Text("${user.name} (${user.role})")
                            }
                        }
                    }
                }
            },
            confirmButton = {
                val canCreate = groupName.isNotBlank() && selectedUsers.isNotEmpty()
                TextButton(
                    onClick = { createGroup() },
                    enabled = canCreate
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showGroupDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ChatDetailScreen(
    chat: AppChat,
    uid: String,
    onBack: () -> Unit
) {
    val db = remember { FirebaseFirestore.getInstance() }
    val chatRef = remember(chat.id) {
        db.collection("chats").document(chat.id)
    }

    var message by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(emptyList<AppMessage>()) }
    var typingUsers by remember { mutableStateOf(emptyList<String>()) }
    var error by remember { mutableStateOf("") }

    DisposableEffect(chat.id, uid) {
        val messageListener: ListenerRegistration =
            chatRef.collection("messages")
                .orderBy("createdAt")
                .addSnapshotListener { snapshot, exception ->
                    if (exception != null) {
                        error = exception.message ?: "Messages load nahi huay"
                        return@addSnapshotListener
                    }

                    val docs = snapshot?.documents ?: emptyList()

                    messages = docs.map { doc ->
                        AppMessage(
                            id = doc.id,
                            senderId = doc.getString("senderId") ?: "",
                            text = doc.getString("text") ?: "",
                            readBy = doc.get("readBy") as? List<String> ?: emptyList()
                        )
                    }

                    docs.filter {
                        it.getString("senderId") != uid &&
                                !(it.get("readBy") as? List<*>)?.contains(uid).orFalse()
                    }.forEach { doc ->
                        doc.reference.update("readBy", FieldValue.arrayUnion(uid))
                    }
                }

        val chatListener = chatRef.addSnapshotListener { snapshot, _ ->
            val typing = snapshot?.get("typing") as? Map<*, *>
            typingUsers = typing?.filter {
                it.key != uid && it.value == true
            }?.keys?.map { it.toString() } ?: emptyList()
        }

        onDispose {
            messageListener.remove()
            chatListener.remove()
            chatRef.update("typing.$uid", false)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("Back") }
            Text(chat.chatName, style = MaterialTheme.typography.titleLarge)
        }

        if (typingUsers.isNotEmpty()) {
            Text("Someone is typing...", modifier = Modifier.padding(horizontal = 12.dp))
        }

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().padding(12.dp)
        ) {
            items(messages) { item ->
                val mine = item.senderId == uid
                Column(
                    Modifier.fillMaxWidth(),
                    horizontalAlignment = if (mine) Alignment.End else Alignment.Start
                ) {
                    Card(Modifier.padding(4.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            Text(item.text)
                            if (mine) {
                                Text(
                                    if (item.readBy.size >= chat.members.size) "Read"
                                    else "Sent",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }
        }

        if (error.isNotBlank()) {
            Text(error, color = MaterialTheme.colorScheme.error)
        }

        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = message,
                onValueChange = {
                    message = it
                    chatRef.update("typing.$uid", it.isNotBlank())
                },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Type a message...") }
            )

            Button(
                onClick = {
                    val text = message.trim()
                    if (text.isNotEmpty()) {
                        val data = hashMapOf(
                            "senderId" to uid,
                            "text" to text,
                            "readBy" to listOf(uid),
                            "createdAt" to FieldValue.serverTimestamp()
                        )

                        chatRef.collection("messages").add(data)
                            .addOnSuccessListener {
                                message = ""
                                error = ""
                                chatRef.update(
                                    mapOf(
                                        "lastMessage" to text,
                                        "updatedAt" to FieldValue.serverTimestamp(),
                                        "typing.$uid" to false
                                    )
                                )
                            }
                            .addOnFailureListener {
                                error = it.message ?: "Message send nahi hua"
                            }
                    }
                },
                modifier = Modifier.padding(start = 6.dp)
            ) {
                Text("Send")
            }
        }
    }
}

private fun Boolean?.orFalse(): Boolean = this ?: false
